/*1 */
SELECT modelName, spaceship_id, modelType, price, maxCapacity, fuelCapacity, image_url FROM sp17_3308_tug25055.spaceship order by modelName;
