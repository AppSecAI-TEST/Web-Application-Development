package dbUtils;

public class SelectOption {

    public String id = "";
    public String name = "";

    public SelectOption(String id, String name) {
        this.id = id;
        this.name = name;
    }
}