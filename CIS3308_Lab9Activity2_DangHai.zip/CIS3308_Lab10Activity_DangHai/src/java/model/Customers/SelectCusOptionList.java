/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.Customers;

/**
 *
 * @author Hai Dang
 */

import java.util.ArrayList;

public class SelectCusOptionList {

    public String dbError = "";
    private ArrayList<StringData> selectOptionList = new ArrayList();

    public SelectCusOptionList() {
    }

    public void addOption(StringData option) {
        this.selectOptionList.add(option);
    }
}