/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

import dbUtils.DbConn;
import dbUtils.FormatUtils;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Hai
 */
public class reportView {
    
    //This function creates the table that the user made.
    public static String listAll(String cssTableClass, DbConn dbc, String sql) {

        // String type could have been used, but StringBuilder is more efficient 
        // in this case where we are just appending
        StringBuilder sb = new StringBuilder("");
        ArrayList<String> colNames = new ArrayList();
        PreparedStatement stmt = null;
        ResultSet results = null;
        try {
            String colQuery = getColumnQuery(sql);
            sb.append("<table class='");
            sb.append(cssTableClass);
            sb.append("'>");
            sb.append(getMetaData(cssTableClass, dbc, colQuery, colNames));
            
            stmt = dbc.getConn().prepareStatement(sql);
            results = stmt.executeQuery();
            ResultSetMetaData rsMetaData = results.getMetaData();
            int numCol = rsMetaData.getColumnCount();
            while(results.next()){
                sb.append("<tr>");
                for(int i = 1; i <= numCol; i++){
                    String type = FormatUtils.formatString(rsMetaData.getColumnTypeName(i)).toLowerCase();
                    System.out.println("type: " + type);
                    String cell = "";
                    System.out.println(i-1 + ": " + results.getObject(colNames.get(i-1)));
                    if(type.equalsIgnoreCase("int")){
                        cell = FormatUtils.formatIntegerTd(results.getObject(colNames.get(i-1)));
                    }else if(type.equalsIgnoreCase("double")){
                        cell = FormatUtils.formatDoubleTd(results.getObject(colNames.get(i-1)));
                    }else if(type.equalsIgnoreCase("varchar")){
                        cell = FormatUtils.formatStringTd(results.getObject(colNames.get(i-1)));
                    }else if(type.equalsIgnoreCase("date")){
                        if(results.wasNull()){
                            cell= FormatUtils.formatStringTd("");
                            System.out.println("Result was null");
                        } else {
                            cell = FormatUtils.formatDateTd(results.getObject(colNames.get(i-1)));
                        }
                    }
                    sb.append(cell);
                }
                sb.append("</tr>\n");
            }
            sb.append("</table>");
            results.close();
            stmt.close();
            return sb.toString();
            
        } catch (Exception e) {
            return "Exception thrown in reportView.listAll(): " + e.getMessage()
                    + "<br/> partial output: <br/>" + sb.toString();
        }
    }
    
    //This method parses the query to get the table with the aliases  (NO LONGER USED)
    public static String getColumnQuery(String sql){
        String sqlSelect= "select ";
        String sqlFrom = "from";
        String query = sql.toLowerCase();
        //If the statement has a where clause
        int indexOfEnd = query.indexOf("where");
        //If the statement has no where clause
        if(indexOfEnd < 0){
            System.out.println("IndexofEnd: " + indexOfEnd);
            indexOfEnd = query.length();
        }
        System.out.println("query: " + 0 + " " + indexOfEnd);

        String columnQuery = query.substring(0, indexOfEnd);
        System.out.println(columnQuery);
        return columnQuery;
    }
    
    //(NO LONGER USED)
    //This function takes in an sql query and returns back the table names 
    public static String getTableName(String sql){
        String sqlFrom = "from";
        String sqlWhere= "where";
        String query = sql.toLowerCase();
        //start of FROM clause
        int indexOfFrom = query.indexOf(sqlFrom);
        //check if user puts no from clause or let DBMS handle it. 

        //If the statement has a WHERE clause
        int indexOfEnd = query.indexOf(sqlWhere);
        //If the statement has no where clause set to end of query
        if(indexOfEnd < 0){
            System.out.println("IndexofEnd: " + indexOfEnd);
            indexOfEnd = query.length();
        }
        System.out.println("query: " + indexOfFrom + " " + indexOfEnd);
        //Will include only words between FROM & WHERE or FROM & end of query
        String tableName = query.substring(indexOfFrom + sqlFrom.length(), indexOfEnd);
        System.out.println(tableName);
        return tableName;
           
    }
    //(NO LONGER USED)
    //This method gets back all of the column names and gets back the alias if it exists
    public static String[] getColumnNames(String sql){
        String sqlSelect= "select ";
        String sqlFrom = "from";
        String alias = " as ";
        int indexStart = sqlSelect.length();
        int indexEnd = sql.indexOf(sqlFrom);
        String columns = sql.substring(indexStart, indexEnd);
        System.out.println("columns: " + columns);
        String columnNames[] = columns.split(",");
        for(int i = 0; i < columnNames.length; i++){
            //check if it has alias and replace column names
            if(columnNames[i].contains(alias)){
                indexStart = columnNames[i].indexOf(alias) + alias.length();
                indexEnd = columnNames[i].length();
                columnNames[i] = columnNames[i].substring(indexStart, indexEnd);
            }
            //System.out.println(i + " " + columnNames[i]);
        }
        return columnNames;
    }
    
    //This function gets back the column names and returns back the column row
    public static String getMetaData(String cssTableClass, DbConn dbc, String colQuery, ArrayList c) {

        // String type could have been used, but StringBuilder is more efficient 
        // in this case where we are just appending
        StringBuilder sb = new StringBuilder("");

        PreparedStatement stmt = null;
        ResultSet results = null;
        try {
            //sb.append("ready to create the statement & execute query " + "<br/>");
            String sql = colQuery + " WHERE 0=1";
            stmt = dbc.getConn().prepareStatement(sql);
            results = stmt.executeQuery();
            ResultSetMetaData rsMetaData = results.getMetaData();
            int numCol = rsMetaData.getColumnCount();
            
            sb.append("<tr>");
            //Write column names down
            for(int i = 1; i <= numCol; i++) {
                sb.append(FormatUtils.formatStringTh(rsMetaData.getColumnLabel(i)));
                c.add(FormatUtils.formatString(rsMetaData.getColumnLabel(i)));
                //System.out.println(rsMetaData.getColumnLabel(i));
            }
            sb.append("</tr>\n");
            results.close();
            stmt.close();
            return sb.toString();
        } catch (Exception e) {
            return "Exception thrown in reportView.getMetaData(): " + e.getMessage()
                    + "<br/> partial output: <br/>" + sb.toString();
        }
    }
}
