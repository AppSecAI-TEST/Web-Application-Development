package model.webUser;

import dbUtils.*;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import dbUtils.FormatUtils;

public class Search {

    public static StringData logonFind(String email, String pw, DbConn dbc) {
        StringData foundData = new StringData();
        if ((email == null) || (pw == null)) {
            foundData.errorMsg = "Search.logonFind: email and pw must be both non-null.";
            return foundData;
        }
        try {

            // prepare (compiles) the SQL statement
            String sql = "select web_user_id, user_email, user_password, membership_fee, "+
                    " birthday from web_user WHERE user_email = ? and user_password = ?";

            // PrepStatement is Sally's wrapper class for java.sql.PreparedStatement
            // Only difference is that Sally's class takes care of encoding null 
            // when necessary. And it also System.out.prints exception error messages.
            PreparedStatement pStatement = dbc.getConn().prepareStatement(sql);

            // Encode string values into the prepared statement (wrapper class).
            pStatement.setString(1, email);
            pStatement.setString(2, pw);

            ResultSet results = pStatement.executeQuery();
            if (results.next()) {
                foundData.webUserId = FormatUtils.formatInteger(results.getObject("web_user_id"));
                foundData.userEmail = email;
                foundData.membershipFee = FormatUtils.formatDollar(results.getObject("membership_fee"));
                foundData.birthday = FormatUtils.formatDate(results.getObject("birthday"));
                return foundData;
            } else {
                return null;
            }
        } catch (Exception e) {
            foundData.errorMsg = "Exception in Search.logonFind: " + e.getMessage();
            System.out.println("******" + foundData.errorMsg);
            return foundData;
        }
    } // logonFind
} // class